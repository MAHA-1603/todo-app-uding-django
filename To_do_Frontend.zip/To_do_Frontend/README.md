# To-Do Application Frontend

## Overview
This repository contains the frontend code for the To-Do application. It includes HTML, CSS, and JavaScript files that implement the core user interface and functionality.

## File Structure
- `index.html`: Main HTML file containing the layout of the application.
- `styles/main.css`: CSS file for styling the application.
- `scripts/main.js`: JavaScript file for adding interactivity to the application.

## Getting Started
1. **Clone the repository**:
    ```sh
    git clone https://github.com/yourusername/todo-application-frontend.git
    ```
2. **Navigate to the project directory**:
    ```sh
    cd todo-application-frontend
    ```
3. **Open `index.html` in your browser** to view the application.

## Usage
- Use the form to add new tasks.
- Tasks will be displayed in the task list section.

## Libraries/Frameworks
- None used at this stage.

## Development
To contribute or modify the code, please follow best practices for HTML, CSS, and JavaScript development.

## License
This project is licensed under the MIT License.
