document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('form');
    const taskList = document.getElementById('task-list');

    form.addEventListener('submit', (event) => {
        event.preventDefault();
        
        const title = document.getElementById('task-title').value;
        const description = document.getElementById('task-description').value;
        const dueDate = document.getElementById('task-due-date').value;
        
        if (title) {
            const taskItem = document.createElement('div');
            taskItem.classList.add('task-item');
            taskItem.innerHTML = `<h3>${title}</h3><p>${description}</p><p>Due Date: ${dueDate}</p>`;
            taskList.appendChild(taskItem);
            
            form.reset();
        }
    });
});
