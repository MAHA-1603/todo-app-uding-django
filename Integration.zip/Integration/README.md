# To-Do Application Backend

## Overview
This repository contains the backend code for the To-Do application using Django. It includes the setup, models, views, and URL configurations.

## File Structure
- `todo_project/`: Main Django project directory.
- `todo/`: Django app directory with models, views, and URL configurations.
- `todo/templates/todo/`: Templates for rendering HTML pages.
- `todo/static/`: Static files such as CSS.

## Getting Started
1. **Clone the repository**:
    ```sh
    git clone https://github.com/yourusername/todo-application-backend.git
    ```
2. **Navigate to the project directory**:
    ```sh
    cd todo_application_backend
    ```
3. **Set up a virtual environment and activate it**:
    ```sh
    virtualenv venv
    source venv/bin/activate  # On Windows use `venv\Scripts\activate`
    ```
4. **Install dependencies**:
    ```sh
    pip install django
    ```
5. **Apply migrations**:
    ```sh
    python manage.py migrate
    ```
6. **Run the server**:
    ```sh
    python manage.py runserver
    ```

## Usage
- **Access the task list** at `http://127.0.0.1:8000/tasks/`
- **View task details** at `http://127.0.0.1:8000/tasks/<id>/`

## Development
Follow best practices for Django development to maintain and extend the application.

## License
This project is licensed under the MIT License.
